#pragma once

#define EMPHF_USE_POPCOUNT 1
#ifndef EMPHF_USE_POPCOUNT
#    define EMPHF_USE_POPCOUNT 0
#endif
