//***************************************************************************
//* Copyright (c) 2015 Saint Petersburg State University
//* Copyright (c) 2011-2014 Saint Petersburg Academic University
//* All Rights Reserved
//* See file LICENSE for details.
//***************************************************************************

/*
 * seq_common.hpp
 *
 *  Created on: Jun 25, 2012
 *      Author: andrey
 */

#ifndef SEQ_COMMON_HPP_
#define SEQ_COMMON_HPP_

typedef u_int64_t seq_element_type;

#endif /* SEQ_COMMON_HPP_ */
