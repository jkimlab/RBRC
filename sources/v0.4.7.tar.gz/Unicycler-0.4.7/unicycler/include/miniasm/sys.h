#ifndef HL_SYS_H
#define HL_SYS_H

double sys_cputime();
double sys_realtime();
void sys_init();
const char *sys_timestamp();

#endif
